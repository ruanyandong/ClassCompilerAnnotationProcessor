package com.ryd.apt_processor;

import com.google.auto.service.AutoService;
import com.ryd.apt_annotation.BindAnim;
import com.ryd.apt_annotation.BindArray;
import com.ryd.apt_annotation.BindColor;
import com.ryd.apt_annotation.BindString;
import com.ryd.apt_annotation.BindView;
import com.ryd.apt_annotation.OnClick;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeSpec;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.ArrayType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;

/**
 * @author : ruanyandong
 * @e-mail : ruanyandong@didiglobal.com
 * @date : 11/23/21 4:10 PM
 * @desc : com.ryd.apt_processor
 */
@AutoService(Processor.class)
public class ButterKnifeProcessor extends AbstractProcessor {

    // 节点工具
    private Elements mElementUtils;
    // 日志工具
    private Messager mMessagerUtils;
    // java文件生成工具
    private Filer mFilerUtils;
    // 类信息工具
    private Types mTypesUtils;
    // 模块名字
    private String mModuleName;
    private String mVersion;

    static final String superClassPackage = "com.ryd.apt_runtime";
    static final String unBinder = "Unbinder";

    private static final String MODULE_NAME = "MODULE_NAME";
    private static final String VERSION = "VERSION";

    @Override
    public synchronized void init(ProcessingEnvironment processingEnvironment) {
        super.init(processingEnvironment);
        mElementUtils = processingEnvironment.getElementUtils();
        mMessagerUtils = processingEnvironment.getMessager();
        mFilerUtils = processingEnvironment.getFiler();
        mTypesUtils = processingEnvironment.getTypeUtils();
        mModuleName = processingEnvironment.getOptions().get(MODULE_NAME);
        mVersion = processingEnvironment.getOptions().get(VERSION);
        mMessagerUtils.printMessage(Diagnostic.Kind.NOTE,"MODULE_NAME "+mModuleName+" VERSION "+mVersion);
    }

    @Override
    public Set<String> getSupportedOptions() {
        HashSet<String> set = new HashSet<>();
        set.add(MODULE_NAME);
        set.add(VERSION);
        return Collections.unmodifiableSet(set);
    }

    @Override
    public Set<String> getSupportedAnnotationTypes() {
        HashSet<String> set = new HashSet<>();
        set.add(BindView.class.getCanonicalName());
        set.add(OnClick.class.getCanonicalName());
        set.add(BindString.class.getCanonicalName());
        set.add(BindAnim.class.getCanonicalName());
        set.add(BindColor.class.getCanonicalName());
        set.add(BindArray.class.getCanonicalName());
        return Collections.unmodifiableSet(set);
    }

    @Override
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.RELEASE_8;
    }


    /**
     *
     * // ButterKnifeProcessor
     * package com.ryd.androidapt;
     *
     * import androidx.annotation.UiThread;
     * import com.ryd.apt_runtime.Unbinder;
     * import java.lang.Override;
     *
     * public class MainActivity_ViewBinding implements Unbinder {
     *   private MainActivity target;
     *
     *   @UiThread
     *   public MainActivity_ViewBinding(final MainActivity target) {
     *     this.target = target;
     *     target.textView = target.findViewById(2131230900);
     *   }
     *
     *   @Override
     *   public void unbind() {
     *     MainActivity target = this.target;
     *     if (target == null) throw new IllegalStateException("Bindings already cleared.");
     *     this.target = null;
     *     target.textView = null;
     *   }
     * }
     *
     * @param set
     * @param roundEnvironment
     * @return
     */

    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {
        if (set == null || set.isEmpty()){
            return false;
        }
        // field BindView
        Set<? extends Element> bindViewVariableElementSet = roundEnvironment.getElementsAnnotatedWith(BindView.class);
        // method OnClick
        Set<? extends Element> onClickExecutableElementSet = roundEnvironment.getElementsAnnotatedWith(OnClick.class);
        // field BindString
        Set<? extends Element> bindStringVariableElementSet = roundEnvironment.getElementsAnnotatedWith(BindString.class);
        // field BindAnim
        Set<? extends Element> bindAnimVariableElementSet = roundEnvironment.getElementsAnnotatedWith(BindAnim.class);
        // field BindColor
        Set<? extends Element> bindColorVariableElementSet = roundEnvironment.getElementsAnnotatedWith(BindColor.class);
        // field BindArray
        Set<? extends Element> bindArrayVariableElementSet = roundEnvironment.getElementsAnnotatedWith(BindArray.class);

        if ((bindViewVariableElementSet == null || bindViewVariableElementSet.isEmpty()) &&
                (onClickExecutableElementSet == null || onClickExecutableElementSet.isEmpty()) &&
                (bindStringVariableElementSet == null || bindStringVariableElementSet.isEmpty()) &&
                (bindAnimVariableElementSet == null || bindAnimVariableElementSet.isEmpty()) &&
                (bindColorVariableElementSet == null || bindColorVariableElementSet.isEmpty()) &&
                (bindArrayVariableElementSet == null || bindArrayVariableElementSet.isEmpty())){
            return false;
        }

        // 存储每个activity里面需要处理的元素,包括字段和方法
        Map<TypeElement, List<Element>> classFieldMap = new HashMap<>();

        // filed BindView
        if (bindViewVariableElementSet != null && !bindViewVariableElementSet.isEmpty()){
            // 收集每个activity里面的BindView元素
            for (Element element:bindViewVariableElementSet) {
                VariableElement variableElement = (VariableElement)element;
                TypeElement typeElement = (TypeElement) variableElement.getEnclosingElement();
                List<Element> elements = classFieldMap.get(typeElement);
                if (elements == null){
                    elements = new ArrayList<>();
                    classFieldMap.put(typeElement,elements);
                }
                elements.add(variableElement);
            }
        }

        // method OnClick
        if (onClickExecutableElementSet != null && !onClickExecutableElementSet.isEmpty()){
            // 收集每个Activity里面的OnClick元素
            for (Element element :onClickExecutableElementSet) {
                ExecutableElement executableElement = (ExecutableElement)element;
                TypeElement typeElement = (TypeElement) executableElement.getEnclosingElement();
                List<Element> elements = classFieldMap.get(typeElement);
                if (elements == null){
                    elements = new ArrayList<>();
                    classFieldMap.put(typeElement,elements);
                }
                elements.add(executableElement);
            }
        }

        // field BindString
        if (bindStringVariableElementSet != null && !bindStringVariableElementSet.isEmpty()){
            for (Element element:bindStringVariableElementSet) {
                VariableElement bindStringVariableElement = (VariableElement)element;
                TypeElement typeElement = (TypeElement) bindStringVariableElement.getEnclosingElement();
                List<Element> elements = classFieldMap.get(typeElement);
                if (elements == null){
                    elements = new ArrayList<>();
                    classFieldMap.put(typeElement,elements);
                }
                elements.add(bindStringVariableElement);
            }
        }

        // field BindAnim
        if (bindAnimVariableElementSet != null && !bindAnimVariableElementSet.isEmpty()){
            for (Element element:bindAnimVariableElementSet) {
                VariableElement bindAnimVariableElement = (VariableElement)element;
                TypeElement typeElement = (TypeElement)bindAnimVariableElement.getEnclosingElement();
                List<Element> elements = classFieldMap.get(typeElement);
                if (elements == null){
                    elements = new ArrayList<>();
                    classFieldMap.put(typeElement,elements);
                }
                elements.add(bindAnimVariableElement);
            }
        }

        // field BindColor
        if (bindColorVariableElementSet != null && !bindColorVariableElementSet.isEmpty()){
            for (Element element:bindColorVariableElementSet) {
                VariableElement bindColorVariableElement = (VariableElement)element;
                TypeElement typeElement = (TypeElement) bindColorVariableElement.getEnclosingElement();
                List<Element> elements = classFieldMap.get(typeElement);
                if (elements == null){
                    elements = new ArrayList<>();
                    classFieldMap.put(typeElement,elements);
                }
                elements.add(bindColorVariableElement);
            }
        }

        // field BindArray
        if (bindArrayVariableElementSet != null && !bindArrayVariableElementSet.isEmpty()){
            for (Element element:bindArrayVariableElementSet){
                VariableElement bindArrayVariableElement = (VariableElement)element;
                TypeElement typeElement = (TypeElement)bindArrayVariableElement.getEnclosingElement();
                List<Element> elements = classFieldMap.get(typeElement);
                if (elements == null){
                    elements = new ArrayList<>();
                    classFieldMap.put(typeElement,elements);
                }
                elements.add(bindArrayVariableElement);
            }
        }

        //遍历 Activity 中的节点，通过 JavaPoet 生成 Java 文件
        for (Map.Entry<TypeElement, List<Element>> entry:classFieldMap.entrySet()) {

            // 获取当前的Activity?
            TypeElement typeElement = entry.getKey();
            // 获取当前Activity下的所有需要处理的元素
            List<Element> elementList = entry.getValue();
            // 获取activity类名
            String activityName = typeElement.getSimpleName().toString();
            // 获取包名
            PackageElement packageElement = (PackageElement)typeElement.getEnclosingElement();
            String packageName = mElementUtils.getPackageOf(typeElement).toString();
            mMessagerUtils.printMessage(Diagnostic.Kind.NOTE," "+packageElement.getSimpleName()+" "+packageElement.getQualifiedName()+" "+packageName);
            // 父类
            ClassName superClassName = ClassName.get(superClassPackage,unBinder);
            // 当前类名
            ClassName className = ClassName.bestGuess(activityName);

            //创建类并继承UnBinder
            TypeSpec.Builder classBuilder = TypeSpec.classBuilder(activityName+"_ViewBinding")
                    .addModifiers(Modifier.PUBLIC)
                    .addSuperinterface(superClassName)
                    .addField(className, "target", Modifier.PRIVATE);


            //创建 unbind 方法
            MethodSpec.Builder unbindBuilder = MethodSpec.methodBuilder("unbind")
                    .addAnnotation(Override.class)
                    .addModifiers(Modifier.PUBLIC);
            unbindBuilder.addStatement("$T target = this.target", className);
            unbindBuilder.addStatement("if (target == null) throw new IllegalStateException(\"Bindings already cleared.\")");
            unbindBuilder.addStatement("this.target = null");

            //创建构造方法
            ClassName uiThreadClassName = ClassName.get("androidx.annotation", "UiThread");
            MethodSpec.Builder constructorBuilder = MethodSpec.constructorBuilder()
                    .addAnnotation(uiThreadClassName)
                    .addParameter(className, "target", Modifier.FINAL)
                    .addModifiers(Modifier.PUBLIC);
            constructorBuilder.addStatement("this.target = target");

            //便利变量集合，在构造方法中完成 findViewById 逻辑
            for (Element element : elementList) {
                if (element instanceof VariableElement && element.getAnnotation(BindView.class) instanceof BindView){
                    //通过注解拿到 id
                    int viewId = element.getAnnotation(BindView.class).value();
                    //获取变量名
                    String fieldName = element.getSimpleName().toString();
                    //$L for Literals 替换字符串
                    //$T for Types 替换类型,可以理解成对象
                    constructorBuilder.addStatement("target.$L = target.findViewById($L)",fieldName, viewId);
                    unbindBuilder.addStatement("target.$L = null", fieldName);

                }else if (element instanceof VariableElement && element.getAnnotation(BindString.class) instanceof BindString){
                    int stringResId = element.getAnnotation(BindString.class).stringId();
                    String fieldName = element.getSimpleName().toString();
                    // target.getString(R.string.app_name)
                    constructorBuilder.addStatement("target.$L = target.getString($L)",fieldName,stringResId);
                    unbindBuilder.addStatement("target.$L = null", fieldName);

                }else if (element instanceof VariableElement && element.getAnnotation(BindAnim.class) instanceof BindAnim){
                    int animResId = element.getAnnotation(BindAnim.class).animResId();
                    String fieldName = element.getSimpleName().toString();
                    // import android.view.animation.AnimationUtils;
                    // AnimationUtils.loadAnimation(this,R.anim.translate_anim)
                    ClassName animationUtilsClassName = ClassName.get("android.view.animation","AnimationUtils");
                    constructorBuilder.addStatement("target.$L = $T.loadAnimation(target,$L)",fieldName,animationUtilsClassName,animResId);
                    unbindBuilder.addStatement("target.$L = null", fieldName);

                }else if (element instanceof VariableElement && element.getAnnotation(BindColor.class) instanceof BindColor){
                    int colorResId = element.getAnnotation(BindColor.class).colorResId();
                    String fieldName = element.getSimpleName().toString();
                    if (element.asType().getKind() == TypeKind.INT){//int color = this.getResources().getColor(R.color.black);
                        constructorBuilder.addStatement("target.$L = target.getResources().getColor($L)",fieldName,colorResId);
                    }else {
                        //ColorStateList colorStateList = AppCompatResources.getColorStateList(this,R.color.teal_200);
                        //import androidx.appcompat.content.res.AppCompatResources;
                        ClassName appCompatResourcesCLassName = ClassName.get("androidx.appcompat.content.res","AppCompatResources");
                        constructorBuilder.addStatement("target.$L = $T.getColorStateList(target,$L)",fieldName,appCompatResourcesCLassName,colorResId);
                        unbindBuilder.addStatement("target.$L = null", fieldName);
                    }

                }else if (element instanceof VariableElement && element.getAnnotation(BindArray.class) instanceof BindArray){
                   //String[] cs_lang = getResources().getStringArray(R.array.cs_language);
                   //TypedArray ta = getResources().obtainTypedArray(R.array.cs_language);
                   //CharSequence[] charSequences = getResources().getTextArray(R.array.cs_language);
                   //int[] ints = getResources().getIntArray(R.array.reminder_methods_values);
                    int arrayResId = element.getAnnotation(BindArray.class).arrayResId();
                    String fieldName = element.getSimpleName().toString();
                    mMessagerUtils.printMessage(Diagnostic.Kind.NOTE,"==="+element.asType().getKind()+" "+element.asType().getKind().getDeclaringClass());

                }else if (element instanceof ExecutableElement && element.getAnnotation(OnClick.class) instanceof OnClick){
                    // 拿到所有需要设置点击监听器的view的id值
                    int[] ids = element.getAnnotation(OnClick.class).value();
                    // 方法名
                    String methodName = element.getSimpleName().toString();
                    ClassName viewName = ClassName.get("android.view","View");
                    for (int id : ids) {
                        String fieldName = String.format("view%d",id);
                        FieldSpec.Builder builder = FieldSpec.builder(viewName,fieldName,Modifier.PRIVATE);
                        classBuilder.addField(builder.build());

                        constructorBuilder.addStatement("view$L = target.findViewById($L)",id,id);

                        ClassName clickListenerClassName = ClassName.get("android.view.View","OnClickListener");
                        TypeSpec onClickListener = TypeSpec.anonymousClassBuilder("")
                                .addSuperinterface(clickListenerClassName)
                                .addMethod(MethodSpec.methodBuilder("onClick")
                                        .addAnnotation(Override.class)
                                        .addModifiers(Modifier.PUBLIC)
                                        .addParameter(viewName, "v")
                                        .returns(void.class)
                                        .addStatement("target.$L()",methodName)
                                        .build())
                                .build();

                        constructorBuilder.addStatement("view$L.setOnClickListener($L)",id,onClickListener);
                        unbindBuilder.addStatement("view$L = null",id);
                    }
                }

            }

            //添加方法
            classBuilder.addMethod(unbindBuilder.build());
            classBuilder.addMethod(constructorBuilder.build());

            //将 Java 写成 Class 文件
            try {
                JavaFile.builder(packageName, classBuilder.build())
                        .addFileComment("ButterKnifeProcessor")
                        .build()
                        .writeTo(mFilerUtils);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return false;
    }

}
